package com.kevintcoughlin.smodr.models;

import android.net.Uri;

public interface IMediaPlayback {
    Uri getUri();
}
