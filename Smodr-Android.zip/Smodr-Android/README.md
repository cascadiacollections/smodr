# Smodr

SModcast Podcast Player for Android

Get it now on [Google Play](https://play.google.com/store/apps/details?id=com.kevintcoughlin.smodr)

![Channels View](https://lh3.googleusercontent.com/CCmHBWtfnwu9aI6GieX0txC45PPONOmnN64iJ0lipLNqm0WRc7hLTj5Oem2Egh3BU3-b=h900)

![Channel View](https://lh3.googleusercontent.com/hNMFrwX7dBXbHDMUa0kB--_AqMcfEMJNO2eVKIW1RV32BrKbTjPCaLKSGZiyD-r-Hi-j=h900)
